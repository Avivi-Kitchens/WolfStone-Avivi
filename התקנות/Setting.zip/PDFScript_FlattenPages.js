var SelPgDlg =
{
    DoDialog: function () { return app.execDialog(this); },
    strGRP1: "rAll",
    strStrtPg: "",
    strEndPg: "",
    GetRadioSel: function (oRslts, aCtrls) {
        for (var strRtn = aCtrls[0]; aCtrls.length > 0; strRtn = aCtrls.pop()) {
            if (oRslts[strRtn] == true)
                return strRtn;
        }
        return "";
    },
    initialize: function (dialog) {
        this.result = "Cancel";
        var dlgInit =
        {
            "tFPg": util.printf("%d", this.strStrtPg),
            "tTPg": util.printf("%d", this.strEndPg),
        };
        dlgInit[this.strGRP1] = true;
        dialog.load(dlgInit);
        dialog.enable(
            {
                "tTPg": false,
                "tFPg": false,
            }
        );
    },
    commit: function (dialog) {
        var oRslt = dialog.store();
        this.strGRP1 = this.GetRadioSel(oRslt, ["rAll", "rCur", "rFro"]);
        this.strStrtPg = oRslt["tFPg"];
        this.strEndPg = oRslt["tTPg"];
    },
    "rFro": function (dialog) {
        dialog.enable({ tFPg: true, tTPg: true });

    },
    "rCur": function (dialog) {
        dialog.enable({ tFPg: false, tTPg: false });

    },
    "rAll": function (dialog) {
        dialog.enable({ tFPg: false, tTPg: false });

    },
    description:
    {
        name: "��� ���� ����",
        elements:
            [
                {
                    type: "view",
                    elements:
                        [
                            {
                                item_id: "sta1",
                                name: "��� ���� ����",
                                type: "static_text",
                            },
                            {
                                type: "view",
                                elements:
                                    [
                                        {
                                            height: 96,
                                            item_id: "cls3",
                                            name: "���� ����",
                                            type: "cluster",
                                            userName: "Page range",
                                            width: 332,
                                            elements:
                                                [
                                                    {
                                                        group_id: "GRP1",
                                                        height: 20,
                                                        item_id: "rAll",
                                                        name: "���",
                                                        type: "radio",
                                                    },
                                                    {
                                                        group_id: "GRP1",
                                                        height: 20,
                                                        item_id: "rCur",
                                                        name: "�����",
                                                        type: "radio",
                                                        variable_Name: "strRange",
                                                    },
                                                    {
                                                        align_children: "align_row",
                                                        height: 20,
                                                        type: "view",
                                                        width: 256,
                                                        elements:
                                                            [
                                                                {
                                                                    group_id: "GRP1",
                                                                    height: 24,
                                                                    item_id: "rFro",
                                                                    name: "���:",
                                                                    type: "radio",
                                                                    width: 12,
                                                                },
                                                                {
                                                                    char_width: 6,
                                                                    height: 24,
                                                                    item_id: "tFPg",
                                                                    type: "edit_text",
                                                                    variable_Name: "strStrtPg",
                                                                },
                                                                {
                                                                    height: 24,
                                                                    item_id: "sta1",
                                                                    name: "�� ��:",
                                                                    type: "static_text",
                                                                },
                                                                {
                                                                    char_width: 6,
                                                                    height: 24,
                                                                    item_id: "tTPg",
                                                                    type: "edit_text",
                                                                    variable_Name: "strEndPg",
                                                                },
                                                                {
                                                                    height: 24,
                                                                    item_id: "sOfN",
                                                                    name: "of (N)",
                                                                    type: "static_text",
                                                                },
                                                            ]
                                                    },
                                                ]
                                        },
                                        {
                                            align_children: "align_fill",
                                            type: "ok_cancel",
                                        },
                                    ]
                            },
                        ]
                },
            ]
    }
};


var PDFScript_DoFlatten = app.trustedFunction(function () {
    app.beginPriv();
    SelPgDlg.strGRP1 = "rAll";
    SelPgDlg.strStrtPg = this.pageNum + 1;
    SelPgDlg.strEndPg = this.numPages;
    SelPgDlg.description.elements[0].elements[1].elements[0].elements[2].elements[4].name = "of (" + this.numPages + ")";
    if ("ok" == app.execDialog(SelPgDlg)) {
        switch (SelPgDlg.strGRP1) {
            case "rAll":
                this.flattenPages(0, this.numPages - 1);
                break;
            case "rCur":
                this.flattenPages(this.pageNum);
                break;
            case "rFro":
                this.flattenPages(SelPgDlg.strStrtPg - 1, SelPgDlg.strEndPg - 1);
                break;
        }
		app.execMenuItem("Save");
    }
    app.endPriv();
});

var strData6FlattenPages =
    "00C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0" +
    "00C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0" +
    "00C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0" +
    "00C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0FF000000FF000000FF000000FF000000FF000000" +
    "00C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0" +
    "00C0C0C000C0C0C000C0C0C0FF000000FF000000FF000000FF000000FF00000000C0C0C000C0C0C0" +
    "00C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0" +
    "00C0C0C000C0C0C0FF000000FF000000FF000000FF00000000C0C0C000C0C0C000C0C0C000C0C0C0" +
    "00C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0" +
    "00C0C0C0FF000000FF000000FF000000FF000000FF00000000C0C0C000C0C0C000C0C0C000C0C0C0" +
    "00C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0" +
    "00C0C0C0FF000000FF000000FF000000FF000000FF00000000C0C0C000C0C0C000C0C0C000C0C0C0" +
    "00C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0" +
    "00C0C0C0FF000000FF000000FF000000FF000000FF000000FF00000000C0C0C000C0C0C000C0C0C0" +
    "00C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0FF000000" +
    "FF000000FF000000FF000000FF000000FF000000FFFFFFFFFF000000FF00000000C0C0C000C0C0C0" +
    "00C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0FF000000" +
    "FF000000FF00000000C0C0C000C0C0C0FF000000FF000000FFFFFFFFFF000000FF00000000C0C0C0" +
    "00C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0" +
    "FF000000FF00000000C0C0C000C0C0C000C0C0C0FF000000FF000000FFFFFFFFFF000000FF000000" +
    "00C0C0C0FF000000FF000000FF000000FF000000FF000000FF000000FF000000FF00000000C0C0C0" +
    "00C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0FF000000FF000000FFFFFFFFFF000000" +
    "00C0C0C0FF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FF000000" +
    "00C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0FF000000FF000000FFFFFFFF" +
    "00C0C0C0FF000000FFFFFFFFFF000000FF000000FF000000FFFFFFFFFFFFFFFFFF00000000C0C0C0" +
    "FF00000000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0FF000000FF000000" +
    "00C0C0C0FF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FF000000" +
    "FF000000FF00000000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0FF000000" +
    "00C0C0C0FF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF" +
    "FFFFFFFFFF00000000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0" +
    "00C0C0C0FF000000FFFFFFFFFF000000FF000000FF000000FF000000FF000000FF000000FF000000" +
    "FFFFFFFFFF00000000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0" +
    "00C0C0C0FF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF" +
    "FFFFFFFFFF00000000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0" +
    "00C0C0C0FF000000FFFFFFFFFF000000FF000000FF000000FF000000FF000000FF000000FF000000" +
    "FFFFFFFFFF00000000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0" +
    "00C0C0C0FF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF" +
    "FFFFFFFFFF00000000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0" +
    "00C0C0C0FF000000FFFFFFFFFF000000FF000000FF000000FFFFFFFFFFFFFFFFFF000000FF000000" +
    "FFFFFFFFFF00000000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C000C0C0C0";

var oIconFlattenPages = null;

oIconFlattenPages = {
    count: 0, width: 20, height: 20,
    read: function (nBytes) { return strData6FlattenPages.slice(this.count, this.count += nBytes); }
};

var oButObjFlattenPages =
{
    cName: "FlattenPages",
    cExec: "PDFScript_DoFlatten()",
    cEnable: "event.rc = (app.doc != null)",
    cMarked: "event.rc = false",
    cTooltext: "Flatten Form Fields and Annots on PDF Pages",
    oIcon: oIconFlattenPages,
    cLabel: "Flatten Pages"
};

try { app.removeToolButton("FlattenPages"); } catch (e) { }

try {
    app.addToolButton(oButObjFlattenPages);
} catch (e) { }